from tkinter import *
from tkinter import messagebox
import base64


def encrypt():
    password = code.get()
    if password == 'SohamDatta':
        screen1 = Toplevel(screen)
        screen1.title('Encryption')
        screen1.geometry("400x200")
        screen1.config(bg='#8383db')

        message = text1.get(1.0, END)
        encode_message = message.encode('ascii')
        base64_bytes = base64.b64encode(encode_message)
        encrypt = base64_bytes.decode('ascii')

        Label(screen1, text='Encrypted Text', font='calibri 18 bold',
              fg='white', bg='#8383db') \
            .place(x=10, y=0)

        text2 = Text(screen1, font="Rpbote 15",
                     bg='white', relief=GROOVE, wrap=WORD, bd=0)
        text2.place(x=10, y=40, width=380, height=150)
        text2.insert(END, encrypt)
    elif password == '':
        messagebox.showerror('encryption',
                             'Input Password')
    elif password != 'Pythonagham':
        messagebox.showerror('encryption',
                             'Invalid Password')


def decrypt():
    password = code.get()
    if password == 'SohamDatta':
        screen2 = Toplevel(screen)
        screen2.title('Decryption')
        screen2.geometry("400x200")
        screen2.config(bg='#6DE46D')

        message = text1.get(1.0, END)
        decode_message = message.encode('ascii')
        base64_bytes = base64 \
            .b64decode(decode_message)
        decrypt = base64_bytes.decode('ascii')

        Label(screen2, text='Decrypted Text', font='calibri 18 bold',
              fg='white', bg='#6DE46D') \
            .place(x=10, y=0)

        text2 = Text(screen2, font="Robote 15", bg='white',
                     relief=GROOVE, wrap=WORD, bd=0)
        text2.place(x=10, y=40, width=380, height=150)
        text2.insert(END, decrypt)
    elif password == '':
        messagebox.showerror('decryption',
                             'Input Password')
    elif password != 'Pythonagham':
        messagebox.showerror('decryption',
                             'Invalid Password')


def main_screen():
    global screen
    global code
    global text1
    screen = Tk()
    screen.geometry('550x610')
    screen.title('Encrypt Decrypt')
    screen.resizable(False, False)
    screen.config(bg='#FBFE97')
    logo = PhotoImage(file="logo.png")
    Label(screen, image=logo, bg="#FBFE97") \
        .place(x=200, y=20)

    title = Label(screen, text='Encrypt - Decrypt',
                  font='poppins 30 bold',
                  bg='#FBFE97', fg='black')
    title.place(x=100, y=150)

    def reset():
        code.set('')
        text1.delete(1.0, END)

    Label(text='Enter text for Encryption'
               ' / Decryption', fg='black',
          font='calibri 15 bold', bg="#FBFE97") \
        .place(x=100, y=225)
    text1 = Text(font='Robote 20', bg='white',
                 relief=GROOVE, wrap=WORD, bd=0)
    text1.place(x=100, y=260, width=360, height=100)

    Label(text="Enter Secret Key", fg='black',
          font='Calibri 15 bold', bg="#FBFE97") \
        .place(x=100, y=375)

    code = StringVar()
    Entry(textvariable=code, width=20, bd=0,
          font='arial 25', show='*') \
        .place(x=100, y=410)
    Button(text="Encrypt", height='1', width=17,
           bg='#8383db', fg='white', font='Calibri 15 bold', bd=0, command=encrypt).place(x=100, y=460)

    Button(text="Decrypt", height='1', width=17,
           bg='#6DE46D', fg='white', font='Calibri 15 bold', bd=0, command=decrypt) \
        .place(x=290, y=460)

    Button(text="Reset", height='1', width=36,
           bg='#6c6c6c', fg='white', font='Calibri 15 bold', bd=0, command=reset) \
        .place(x=100, y=510)

    screen.mainloop()


main_screen()
